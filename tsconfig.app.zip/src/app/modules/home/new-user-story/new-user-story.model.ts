export class NewUserStory{
    Id:number;
    Name:string;
    ProjectId:number;
    IsRecurring:boolean;
    DefaultHours:number;
    EmployeeId:number;
    Status:boolean;
}