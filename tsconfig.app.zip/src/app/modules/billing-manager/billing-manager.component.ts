import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-billing-manager',
  templateUrl: './billing-manager.component.html',
  styleUrls: ['./billing-manager.component.scss']
})
export class BillingManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
