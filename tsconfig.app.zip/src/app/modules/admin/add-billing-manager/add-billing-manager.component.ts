import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-billing-manager',
  templateUrl: './add-billing-manager.component.html',
  styleUrls: ['./add-billing-manager.component.scss']
})
export class AddBillingManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
