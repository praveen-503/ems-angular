import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-employee-disignation',
  templateUrl: './view-employee-disignation.component.html',
  styleUrls: ['./view-employee-disignation.component.scss']
})
export class ViewEmployeeDisignationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
