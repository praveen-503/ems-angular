import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-reviewer',
  templateUrl: './add-reviewer.component.html',
  styleUrls: ['./add-reviewer.component.scss']
})
export class AddReviewerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
