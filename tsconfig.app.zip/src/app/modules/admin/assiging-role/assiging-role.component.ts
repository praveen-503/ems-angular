import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assiging-role',
  templateUrl: './assiging-role.component.html',
  styleUrls: ['./assiging-role.component.scss']
})
export class AssigingRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
