export class Project {
    Id:number;
    ClientId:number;
    Name:string;
}