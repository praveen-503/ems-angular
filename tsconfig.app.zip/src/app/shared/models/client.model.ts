export class Client {
    Id:number;
    Name:string;
}