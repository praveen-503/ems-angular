export class Employee{
	Id:number;
    EmployeeId: number;
    Name:string;
    Password:string;
    ProjectId:number;
    IsAccept:boolean;
}